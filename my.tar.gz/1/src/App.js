
import logo from './logo.svg';
import './App.css';


import React, { Component } from 'react'
import axios from 'axios'

import TronWeb from 'tronweb'

const HttpProvider = TronWeb.providers.HttpProvider;

const fullNode = new HttpProvider('https://sonicxscan.com:8090');
const solidityNode = new HttpProvider('https://165.22.52.91:8091/');
const eventServer = 'https://api.shasta.trongrid.io';
const privateKey = 'da146374a75310b9666e834ee4ad0866d6f4035967bfc76217c5a495fff9f0d0';

//
export default class App extends Component {
    constructor() {
        super() 
        this.state = {
            repos: [],
            btnPressed: false,
        }
    }    async getRepos() {
        console.log("clicked")
            const tronWeb = new TronWeb(
           fullNode,
           solidityNode,
           eventServer,
           privateKey
            );
            console.log("created1")
           // tronWeb.setDefaultBlock('latest');

            //  const userBalance = await tronWeb.trx.getBalance("SfeDfQ4VJiJD8UeeZvFPXMX434HKyWby4v");

            const userBalance = await tronWeb.trx.getTransactionFromBlock(12345);
            console.log(userBalance);
            //console.log('User  balance is: ${ userBalance }');

            const nodes = await tronWeb.isConnected();
            const connected = !Object.entries(nodes).map(([name, connected]) => {
                if (!connected)
                    console.error(`Error: ${name} is not connected`);

            return connected;
        }).includes(false);

        if (!connected)
            return;


        /*
        var axiosInstance = axios.create({
            baseURL: 'https://api.github.com/user',
            headers: {
                'Authorization': `token ${GH_TOKEN}`
                */
        
}
       

           
        
     displayApp() {
         return <button onClick={this.getRepos.bind(this)}>Get Repos</button>
   
    }    

render() {
    return (
        <div>
            <h1>React App</h1>
    {this.displayApp()}
    </div>
    )
   }
}

